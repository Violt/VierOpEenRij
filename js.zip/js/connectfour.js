import {ConnectFourController} from "./controls/ConnectFourController.js";

window.addEventListener('load', e=>{
    let c = new ConnectFourController();
})